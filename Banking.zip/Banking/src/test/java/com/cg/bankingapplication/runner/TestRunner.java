package com.cg.bankingapplication.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty","json:target/cucumber-json-report"},
features= {"src/test/resources/features"},
glue= {"com.cg.bankingapplicationstep"})

public class TestRunner {

	
}
