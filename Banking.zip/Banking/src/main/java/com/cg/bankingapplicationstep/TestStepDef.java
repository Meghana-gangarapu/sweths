package com.cg.bankingapplicationstep;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.cg.bankingappilacation.dto.Address;
import com.cg.bankingappilacation.dto.Customer;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestStepDef {
	Customer cust;
	Address addr;
	@Given("^Account holder name address$")
	public void account_holder_name_address() throws Throwable {
	   addr=new Address("chennai","TM");
	   cust=new Customer("abcd",1300,addr);
	}

	@When("^User name is given$")
	public void user_name_is_given() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertNotNull(cust);
	   assertFalse(cust.getCustomerName().isEmpty());
	}


	@When("^Opening balance is greater then  minimum (\\d+)$")
	public void opening_balance_is_greater_then_minimum_amount(int amount) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertTrue(cust.getBalance()>=(amount));
	}

	@Then("^Open account and save into database$")
	public void open_account_and_save_into_database() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


}
