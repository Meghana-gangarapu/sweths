package com.cg.service;

import java.util.List;

import com.cg.entities.ScheduledSessions;

;

public interface ScheduledSessionsService {

		public abstract List<ScheduledSessions> showSessions();

}
