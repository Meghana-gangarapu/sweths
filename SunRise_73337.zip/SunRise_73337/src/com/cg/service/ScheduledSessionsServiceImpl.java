package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ScheduledSessionsDao;
import com.cg.entities.ScheduledSessions;


@Service
@Transactional
public class ScheduledSessionsServiceImpl  implements ScheduledSessionsService{
   
	
	//creating an object for Dao Layer
	@Autowired
	ScheduledSessionsDao scheduledSessionsDao;
	
	
	@Override
	public List<ScheduledSessions> showSessions() {
		// TODO Auto-generated method stub
		return scheduledSessionsDao.showSessions() ;
	}

}
