package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ecxeptions.SessionNotFoundException;
import com.cg.service.ScheduledSessionsService;
//Making class as a Controller
@Controller
public class ScheduledSessionsController {

	//object creation for Service Class
	@Autowired
	 private ScheduledSessionsService scheduledSessionsService;
	
	
	@RequestMapping("/ScheduledSessions")
	public String showTranscations(Model model) throws SessionNotFoundException {
		model.addAttribute("ScheduledSessions",scheduledSessionsService.showSessions());
		return "SchelduledSessions";
		}
	
	
    

	@RequestMapping("/Success")
	public String showPage(@RequestParam("name") String name, Model model)
	{
		model.addAttribute("name", name);
	    return "Success";
	}
	

	
}
