package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.ScheduledSessions;

//Making class as repository class
@Repository
public class ScheduledSessionsDaoImpl implements ScheduledSessionsDao {
	
//Inserting Entity Manager Using Annotation	
	@PersistenceContext
	private EntityManager entityManager;

	
	//Retrieving Sessions from Database
	@Override
	public List<ScheduledSessions> showSessions() {
		TypedQuery<ScheduledSessions> query=entityManager.createQuery("select s from ScheduledSessions s",ScheduledSessions.class);
		return query.getResultList();
	}

}
