package com.cg.dao;

import java.util.List;

import com.cg.entities.ScheduledSessions;

public interface ScheduledSessionsDao  {

public 	List<ScheduledSessions> showSessions();

}
