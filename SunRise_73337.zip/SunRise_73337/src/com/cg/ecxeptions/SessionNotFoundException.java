package com.cg.ecxeptions;






@SuppressWarnings("serial")
public class SessionNotFoundException extends Exception {

	
		public SessionNotFoundException() {
			super();
			// TODO Auto-generated constructor stub
		}

		public SessionNotFoundException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
		 
	}

