package com.cg.dao;

import java.util.List;

import com.cg.entities.Employee;

public interface EmployeeRepository {
	public Employee save(Employee employee);
	public List<Employee> loadAll();
}
