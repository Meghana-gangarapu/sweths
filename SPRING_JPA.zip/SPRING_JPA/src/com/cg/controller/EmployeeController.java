package com.cg.controller;

import org.cg.entities.Employee;
import org.cg.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService; 
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee") Employee employee ,Model model) {
		employee=employeeService.save(employee);
		model.addAttribute("message", "Employee with id"+employee.getEmployeeId()+"added sucessfully");
		return "redirect:/index.html";
	}

@RequestMapping("/index")
public String homePage(Model model) {
	model.addAttribute("empList", employeeService.loadAll());
	model.addAttribute("designations", new String[] {"Systemassociate","asst","manager","dy manger"});
	model.addAttribute("employee", new Employee());
	return "index";
	}
}
