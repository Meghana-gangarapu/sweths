package com.cg.dao;

import java.util.List;

import org.cg.entities.Employee;
import org.springframework.stereotype.Repository;

public interface EmployeeRepository {
	public abstract Employee save(Employee employee);
	public abstract List<Employee>loadAll();
}
