package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.cg.entities.Employee;
import org.springframework.stereotype.Repository;
@Repository
public class EmployeeRepositoryimpl implements  EmployeeRepository  {
	@PersistenceContext
private EntityManager entitymanager;
	@Override
	public Employee save(Employee employee) {
entitymanager.persist(employee);
entitymanager.flush();
		return employee;
	}

	@Override
	public List<Employee> loadAll() {
	
		TypedQuery<Employee> query=	entitymanager.createQuery("select e From Employee e",Employee.class);
		return query.getResultList();
	}


}
