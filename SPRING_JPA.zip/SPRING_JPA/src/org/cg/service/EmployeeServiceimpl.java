package org.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.cg.entities.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeRepository;
@Service
@Transactional
public class EmployeeServiceimpl implements  EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public List<Employee> loadAll() {
		// TODO Auto-generated method stub
		return employeeRepository.loadAll();
	}

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		return  employeeRepository.save(employee);
	}

}
