package org.cg.service;

import java.util.List;

import org.cg.entities.Employee;
import org.springframework.stereotype.Service;

public interface EmployeeService {
public abstract Employee save(Employee employee);
public abstract List<Employee>loadAll();
}
