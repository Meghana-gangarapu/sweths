package com.cg.dao;

import com.cg.entities.QueryAnswers;

public interface IQueryDAO {

	QueryAnswers find(int questionId);

	void save(QueryAnswers queryAnswers);

}
