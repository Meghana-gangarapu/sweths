package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.QueryAnswers;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public QueryAnswers find(int questionId) {
		return entityManager.find(QueryAnswers.class, questionId);
	}

	@Override
	public void save(QueryAnswers queryAnswers) {
		QueryAnswers queryAnswers1=entityManager.find(QueryAnswers.class, queryAnswers.getQueryId());
		queryAnswers1.setSolutions(queryAnswers.getSolutions());
		queryAnswers1.setSolutionGivenBy(queryAnswers.getSolutionGivenBy());
	}

	
}
