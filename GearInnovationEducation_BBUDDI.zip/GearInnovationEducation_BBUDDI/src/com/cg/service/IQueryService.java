package com.cg.service;

import com.cg.entities.QueryAnswers;

public interface IQueryService {

	QueryAnswers find(int questionId);

	void save(QueryAnswers queryAnswers);

}
