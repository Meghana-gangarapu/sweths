package com.cg.service;

import com.cg.entities.BookEntities;



public interface BookService {
	BookEntities find(int custId);
	void save(BookEntities queryAnswers);
}
