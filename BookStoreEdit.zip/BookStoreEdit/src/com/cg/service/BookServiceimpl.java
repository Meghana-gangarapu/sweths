package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BookDao;

import com.cg.entities.BookEntities;
@Service
@Transactional
public class BookServiceimpl implements BookService {
	@Autowired
	BookDao iQueryDAO;
	@Override
	public BookEntities find(int custId) {
		
		return iQueryDAO.find(custId);
	}
	@Override
	public void save(BookEntities queryAnswers) {
		iQueryDAO.save(queryAnswers);
		
	}

}
