package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.BookEntities;



@Repository
public class BookDaoimpl implements BookDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public BookEntities find(int custId) {
		return entityManager.find(BookEntities.class, custId);
	}

	@Override
	public void save(BookEntities queryAnswers) {
		BookEntities queryAnswers1=entityManager.find(BookEntities.class, queryAnswers.getCustId());
		queryAnswers1.setPrice(queryAnswers.getPrice());
		queryAnswers1.setCategory(queryAnswers.getCategory());
		
	}
	

}
