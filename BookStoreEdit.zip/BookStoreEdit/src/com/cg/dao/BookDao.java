package com.cg.dao;

import com.cg.entities.BookEntities;


public interface BookDao {
	BookEntities find(int custId);
	void save(BookEntities queryAnswers);
}
