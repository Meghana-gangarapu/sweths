package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.model.Stock;

@Repository("stockDao")
public class StockDAOImpl implements StockDAO{
	
	  @PersistenceContext
		EntityManager entityManager;
	  
		public EntityManager getEntityManager() {
			return entityManager;
		}
		public void setEntityManager(EntityManager entityManager) {
			this.entityManager = entityManager;
		}    
	
	@Override
	public List<Stock> getAllStock() {
		Query q=entityManager.createQuery("from Stock");
		List<Stock> list=q.getResultList();
		return list;
	}
	@Override
	public Stock getById(int stockId) {
		Stock s=entityManager.find(Stock.class,stockId);
		return s;
	}
	
	@Override
	public double buy(int stock_code,int quantity ) {
		Stock newstock=entityManager.find(Stock.class,stock_code);
		double buy=Double.parseDouble(newstock.getQuote())*quantity;
		return buy;
		
	}
	
	

}
