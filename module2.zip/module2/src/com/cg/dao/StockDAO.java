package com.cg.dao;

import java.util.List;

import com.cg.model.Stock;

public interface StockDAO {
	public List<Stock> getAllStock();

	Stock getById(int stockId);

	double buy(int stock_code, int quantity);
}
