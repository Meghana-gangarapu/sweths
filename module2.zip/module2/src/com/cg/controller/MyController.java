package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Stock;

import com.cg.service.StockService;

@Controller
public class MyController {
	@Autowired
	StockService stockService;

	@RequestMapping("/index")
	public String index(Model m) {

		List<Stock> stocklist = stockService.getAllProducts();
		m.addAttribute("slist", stocklist);
		return "index";
	}

	@RequestMapping("/reliance industries")
	public ModelAndView reliance(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		Stock st1 = stockService.getById(sid);
		session.setAttribute("user", st1);
		view.setViewName("order");
		return view;

	}

	@RequestMapping("/tata steel")
	public ModelAndView tcs(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		Stock st1 = stockService.getById(sid);
		session.setAttribute("user", st1);
		view.setViewName("order");
		return view;

	}

	@RequestMapping("/lnt")
	public ModelAndView lnt(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		Stock st1 = stockService.getById(sid);
		session.setAttribute("user", st1);
		view.setViewName("order");
		return view;

	}

	@RequestMapping("/save")
	public ModelAndView save(HttpServletRequest request,@RequestParam("opt")String opt) {
		ModelAndView view = new ModelAndView();
		double amount;
		int quantity;
		HttpSession session = request.getSession();
		String str=opt;
		
		Stock st1=(Stock) session.getAttribute("user");
		session.setAttribute("opt",str);
		if(str.charAt(0)=='B') {
			quantity=Integer.parseInt(request.getParameter("quantity"));
			amount=stockService.buy(st1.getStock_code(),quantity);
		}else {
			 quantity=Integer.parseInt(request.getParameter("quantity"));
			amount=stockService.buy(st1.getStock_code(),quantity);
		}
		session.setAttribute("amount", amount);
		session.setAttribute("quantity",quantity);
		view.setViewName("summary");
		return view;
	}
	
	@RequestMapping("/summary")
	public ModelAndView summary(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		view.setViewName("summary");
		return view;
		
	}
	
	
	
	
	
	
	
	
	
}
