package com.cg.service;

import java.util.List;

import com.cg.model.Stock;

public interface StockService {

	List<Stock> getAllProducts();

	Stock getById(int stockId);
	double buy(int stock_code, int quantity);
}
