package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StockDAO;
import com.cg.model.Stock;
@Service("stockService")
public class StockServiceImpl implements StockService{
 
	@Autowired
	StockDAO stockDao;
	@Override
	public List<Stock> getAllProducts() {
		
		return stockDao.getAllStock();
	}
	@Override
	public Stock getById(int stockId) {
		
		return stockDao.getById(stockId);
	}
	@Override
	public double buy(int stock_code, int quantity) {
		// TODO Auto-generated method stub
		return stockDao.buy(stock_code, quantity);
	}
}
