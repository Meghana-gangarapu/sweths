package com.cg.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name = "stock_master2")
public class Stock implements Serializable {
	@Id
	@GeneratedValue(generator = "ss", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "ss", sequenceName = "sseq2", initialValue = 1, allocationSize = 1)
	private int stock_code;
	private String sname;
	
	private String quote;

	

	public Stock() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	

	public String getQuote() {
		return quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}

	public Stock(String sname, int stock_code, String quote) {
		super();
		this.sname = sname;
		this.stock_code = stock_code;
		this.quote = quote;
	}

	public int getStock_code() {
		return stock_code;
	}

	public void setStock_code(int stock_code) {
		this.stock_code = stock_code;
	}

 }