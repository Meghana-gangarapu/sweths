package com.cg.hotelbooking.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Hotelbooking {
	@FindBy(how=How.ID,id="txtFirstName")
WebElement firstElement;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtLastName\"]")
WebElement lastElement;
	@FindBy(how=How.NAME,name="Email")
	WebElement email;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtPhone\"]")
	WebElement mobile;
	@FindBy(how=How.NAME,name="city")
	WebElement city;
	@FindBy(how=How.NAME,name="state")
	WebElement state;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtCardholderName\"]")
	WebElement cardholder;
	@FindBy(how=How.ID,name="debit")
	WebElement debitcard;
	@FindBy(how=How.NAME,name="cvv")
	WebElement cvv;
	@FindBy(how=How.NAME,name="month")
	WebElement Expirationmonth;
	@FindBy(how=How.NAME,name="year")
		WebElement ExpirationYear;
			@FindBy(how=How.ID,id="btnPayment")
			WebElement button;
			public void clickButton()
			{
				button.click();
			}
			public void setFirstElement(String firstname) {
				this.firstElement.sendKeys(firstname);
			}
			public void setLastElement(String lastname) {
				this.lastElement.sendKeys(lastname);;
			}
			public void setEmail(String email) {
				this.email.clear();
				this.email.sendKeys(email);
			}
			
			public void setMobile(String mobilen) {
				this.mobile.clear();
				this.mobile.sendKeys(mobilen);
			}
			public void setCity(String city) {
				this.city.sendKeys(city);
			}
			public void setState(String state) {
				this.state.sendKeys(state);
			}
			public void setCardholder(String cardholder ) {
				this.cardholder.sendKeys(cardholder);
			}
			public void setDebitcard(String debitcard) {
				this.debitcard.sendKeys(debitcard);
			}
			public void setCvv(String cvv) {
				this.cvv.sendKeys(cvv);
			}
			public void setExpirationmonth(String expirationmonth) {
				this.Expirationmonth.sendKeys(expirationmonth);
			}
			public void setExpirationYear(String expirationYear) {
				this.ExpirationYear.sendKeys(expirationYear);
			}
			
			
			
}