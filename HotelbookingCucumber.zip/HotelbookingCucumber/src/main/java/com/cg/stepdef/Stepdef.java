package com.cg.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.hotelbooking.bean.Hotelbooking;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	/*String title;
	By firstName;
	By lastName;
	By email;
	By mobile;
	By city;
	By state;
	By cardholder;
	By debitcard;
	By cvv;
	By Expirationmonth;
	By ExpirationYear;
	By button;*/
	Hotelbooking hotelbean;
	String title;
	WebDriver driver;
	@Before
	public  void init() {
	System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	driver.manage().window().maximize();
	hotelbean=new Hotelbooking();
	PageFactory.initElements(driver, hotelbean);//to pass page 
	

	}
	@After
	public void finish() throws Exception 
	{
	Thread.sleep(5000);
	driver.quit();
	}
@Given("^Hotel booking page for validation$")
public void hotel_booking_page_for_validation() throws Throwable {
	driver.get("file:///C:/Users/MEGANGAR/Desktop/megha/HotelbookingCucumber/target/web_page/hotelbooking.html");
	
	/*firstName=By.id("txtFirstName");
	lastName=By.name("txtLN");
	email=By.id("txtEmail");
	mobile=By.id("txtPhone");
	city=By.name("city");
	state=By.name("state");
	cardholder=By.id("txtCardholderName");
	debitcard=By.id("txtDebit");
	cvv=By.name("cvv");
	Expirationmonth=By.xpath("//*[@id=\"txtMonth\"]");
	ExpirationYear=By.xpath("//*[@id=\"txtYear\"]");
	button=By.xpath("//*[@id=\"btnPayment\"]");*/
	
}

@When("^Checking title of hotel booking$")
public void checking_title_of_hotel_booking() throws Throwable {
	title=driver.getTitle();
}

@Then("^check titile is Hotel Booking$")
public void check_titile_is_Hotel_Booking() throws Throwable {
   String expected="Hotel Booking";
   String actual=title;
   assertEquals(expected, actual);
}

@When("^Enter submit without entering firstname$")
public void enter_submit_without_entering_firstname() throws Throwable {

	//driver.findElement(button).click();
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with  Please fill the First Name$")
public void get_alert_with_Please_fill_the_First_Name() throws Throwable {

	String actual=driver.switchTo().alert().getText();
	String expected="Please fill the First Name";
	assertEquals(expected, actual);

}

@When("^Enter submit without entering lastname$")
public void enter_submit_without_entering_lastname() throws Throwable {
	 
	driver.switchTo().alert().dismiss();
	hotelbean.setFirstElement("megha");
	hotelbean.clickButton();
	//driver.findElement(firstName).sendKeys("megha");
	//driver.findElement(button).click();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the Last Name$")
public void get_alert_with_Please_fill_the_Last_Name() throws Throwable {

String actual=driver.switchTo().alert().getText();
String expected="Please fill the Last Name";
 assertEquals(expected,actual);
 
}

@When("^Enter submit without entering email$")
public void enter_submit_without_entering_email() throws Throwable {
	driver.switchTo().alert().dismiss();
	hotelbean.setLastElement("var");
	hotelbean.clickButton();
	//driver.findElement(lastName).sendKeys("maggie");
	//driver.findElement(button).click();
	Thread.sleep(1000);
	 
}

@Then("^Get alert with Please fill the Email$")
public void get_alert_with_Please_fill_the_Email() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please fill the Email";
	assertEquals(expected,actual);
}

@When("^Enter submit with invalid email$")
public void enter_submit_with_invalid_email() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(email).sendKeys("var");
//	driver.findElement(button).click();
	hotelbean.setEmail("nvjgf");
	hotelbean.clickButton();
	Thread.sleep(1000);
	 
}

@Then("^Get alert with Please enter valid Email Id\\.$")
public void get_alert_with_Please_enter_valid_Email_Id() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please enter valid Email Id.";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering mobile number$")
public void enter_submit_without_entering_mobile_number() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(email).clear();
	//driver.findElement(email).sendKeys("mv@gmail.com");
	//driver.findElement(button).click();
	hotelbean.setEmail("mv@gmail.com");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the mobile number$")
public void get_alert_with_Please_fill_the_mobile_number() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please fill the Mobile No.";
	assertEquals(expected,actual);
}

@When("^Enter submit with invalid mobile$")
public void enter_submit_with_invalid_mobile() throws Throwable {
	driver.switchTo().alert().dismiss();

	//driver.findElement(mobile).sendKeys("12");
	//driver.findElement(button).click();
	
	hotelbean.setMobile("123");
	hotelbean.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert with Please enter valid Contact no\\.$")
public void get_alert_with_Please_enter_valid_Contact_no() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please enter valid Contact no.";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering city$")
public void enter_submit_without_entering_city() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(mobile).clear();
	//driver.findElement(mobile).sendKeys("9875276456");
	//driver.findElement(button).click();
	hotelbean.setMobile("9787654321");
	hotelbean.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert with Please fill the city$")
public void get_alert_with_Please_fill_the_city() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please select city";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering state$")
public void enter_submit_without_entering_state() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(email).clear();
	//driver.findElement(city).sendKeys("Chennai");
	//driver.findElement(button).click();
	hotelbean.setCity("Chennai");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the state$")
public void get_alert_with_Please_fill_the_state() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	String expected="Please select state";
	assertEquals(expected,actual);
   }




@When("^Enter submit without entering Card holder name$")
public void enter_submit_without_entering_Card_holder_name() throws Throwable {
	driver.switchTo().alert().dismiss();
//	driver.findElement(state).sendKeys("Telangana");
	//driver.findElement(button).click();
	hotelbean.setState("Telangana");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the Card holder name$")
public void get_alert_with_Please_fill_the_Card_holder_name() throws Throwable {
String actual=driver.switchTo().alert().getText();
	
	String expected="Please fill the Card holder name";
	assertEquals(expected,actual);
}


@When("^Enter submit without entering debit card number$")
public void enter_submit_without_entering_debit_card_number() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(cardholder).sendKeys("vasu");
	//driver.findElement(button).click();
	hotelbean.setCardholder("vas");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the debit card number$")
public void get_alert_with_Please_fill_the_debit_card_number() throws Throwable {
String actual=driver.switchTo().alert().getText();
	
	String expected="Please fill the Debit card Number";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering cvv$")
public void enter_submit_without_entering_cvv() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(debitcard).sendKeys("1234");
	//driver.findElement(button).click();
	hotelbean.setDebitcard("1234");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the cvv$")
public void get_alert_with_Please_fill_the_cvv() throws Throwable {
String actual=driver.switchTo().alert().getText();
	
	String expected="Please fill the CVV";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering Expirationmonth$")
public void enter_submit_without_entering_Expirationmonth() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(cvv).sendKeys("568");
	//driver.findElement(button).click();
	hotelbean.setCvv("756");
	hotelbean.clickButton();
	Thread.sleep(1000);
}


@Then("^Get alert with Please fill the Expirationmonth$")
public void get_alert_with_Please_fill_the_Expirationmonth() throws Throwable {
String actual=driver.switchTo().alert().getText();
	
	String expected="Please fill expiration month";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering ExpirationYear$")
public void enter_submit_without_entering_ExpirationYear() throws Throwable {
	driver.switchTo().alert().dismiss();
	//driver.findElement(Expirationmonth).sendKeys("june");
	//driver.findElement(button).click();
	hotelbean.setExpirationmonth("june");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert with Please fill the ExpirationYear$")
public void get_alert_with_Please_fill_the_ExpirationYear() throws Throwable {
String actual=driver.switchTo().alert().getText();
	
	String expected="Please fill the expiration year";
	assertEquals(expected,actual);
}


@When("^all the details are filled$")
public void all_the_details_are_filled() throws Throwable {
	driver.switchTo().alert().dismiss();
	hotelbean.setExpirationYear("2019");
	hotelbean.clickButton();
	Thread.sleep(1000);
}

@Then("^click submit$")
public void click_submit() throws Throwable {


	
}

}
