package com.cg.dao;


import com.cg.entities.QueryAnswersme;

public interface Qdao {
	QueryAnswersme find(int questionId);
	void save(QueryAnswersme queryAnswers);
}
