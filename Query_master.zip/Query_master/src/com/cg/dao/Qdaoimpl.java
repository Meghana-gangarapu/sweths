package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cg.entities.QueryAnswersme;
@Repository
public class Qdaoimpl implements Qdao {


	@PersistenceContext
	EntityManager entityManager;
	@Override
	public QueryAnswersme find(int questionId) {
		return entityManager.find(QueryAnswersme.class, questionId);
	}
	@Override
	public void save(QueryAnswersme queryAnswers) {
		QueryAnswersme queryAnswers1=entityManager.find(QueryAnswersme.class, queryAnswers.getQueryId());
		queryAnswers1.setSolutions(queryAnswers.getSolutions());
		queryAnswers1.setSolutionGivenBy(queryAnswers.getSolutionGivenBy());
		
	}

}
