package com.cg.services;



import com.cg.entities.QueryAnswersme;

public interface Qservice {
 QueryAnswersme find(int questionId);
		// TODO Auto-generated method stub
	
 void save(QueryAnswersme queryAnswers);
}
