package com.cg.bookstore.controller;

import org.hibernate.annotations.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.entities.BookEntities;
import com.cg.bookstore.services.BookService;

@RestController
@RequestMapping(value = "/rest")
public class BookStoreController {

	@Autowired
	BookService bookService;

	@RequestMapping(value = "home")
	public String start() {
		return "Welcome to Book Store";

	}
    @CrossOrigin(origins="http://localhost:4200")
	@RequestMapping(method=RequestMethod.POST, value="/book")
	public BookEntities create(@RequestBody BookEntities book) {
		return bookService.create(book);
	}
//		@RequestMapping(value="/book")
//		public BookEntities bookData() {
//		/*
//		 * BookEntities book=new BookEntities(); book.setCategory("HIHH");
//		 * book.setTitle("veera"); book.setAuthor("by ramana"); book.setIsbn("jkhuihi");
//		 * book.setPrice(9.0f); book.setDescription("hei good vook"); // BookEntities
//		 * bookentities; // Date publishdate=Calendar.getInstance().getTime();
//		 */			
//			
//			BookEntities book= new BookEntities("cat","tit","aut","isb",12f,"dec");
//			bookService.newBook(book);

//			return book;
//			
//		}
//		

}
