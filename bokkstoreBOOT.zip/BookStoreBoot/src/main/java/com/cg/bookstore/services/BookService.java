package com.cg.bookstore.services;

import com.cg.bookstore.entities.BookEntities;


public interface BookService {
	//public BookEntities newBook(BookEntities book);
	public BookEntities create(BookEntities book );
}
