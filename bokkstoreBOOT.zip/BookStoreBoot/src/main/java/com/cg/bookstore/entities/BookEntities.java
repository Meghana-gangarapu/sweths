package com.cg.bookstore.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
//@Component
@Table(name = "Bookstore_master")
public class BookEntities {

	@Id
	@GeneratedValue(/* generator = "book", */strategy = GenerationType.AUTO)
//	@SequenceGenerator(name = "book", sequenceName = "book1", initialValue = 1, allocationSize = 1)
	private int bookId;
//	@NotEmpty(message = "category is mandatory")
	private String category;
//	@NotEmpty(message = "title is mandatory")
	private String title;
//	@NotEmpty(message = "author is mandatory")
	private String author;
//	@NotEmpty(message = "isbn is mandatory")
//	@Size(min = 10, max = 15, message = "isbn should be between 5 to 10")
	private String isbn;
//	@NotEmpty(message = "date is mandatory")
//private Date publicDate;
//	@NotEmpty(message="price is mandatory")
	private double price;
//	@NotEmpty(message = "description is mandatory")
	private String description;

	public BookEntities() {
		super();
	}

	public BookEntities(@NotEmpty(message = "category is mandatory") String category,
			@NotEmpty(message = "title is mandatory") String title,
			@NotEmpty(message = "author is mandatory") String author,
			@NotEmpty(message = "isbn is mandatory") @Size(min = 10, max = 15, message = "isbn should be between 5 to 10") String isbn,
			@NotEmpty(message = "date is mandatory") float price,
			@NotEmpty(message = "description is mandatory") String description) {
		super();
		this.category = category;
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.price = price;
		this.description = description;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

//	public Date getPublicDate() {
//		return publicDate;
//	}
//	public void setPublicDate(Date publicDate) {
//		this.publicDate = publicDate;
//	}
	

	public String getDescription() {
		return description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "BookEntities [bookId=" + bookId + ", category=" + category + ", title=" + title + ", author=" + author
				+ ", isbn=" + isbn + ", price=" + price + ", description=" + description + "]";
	}

//	@Override
//	public String toString() {
//		return "BookEntities [bookId=" + bookId + ", category=" + category + ", title=" + title + ", author=" + author
//				+ ", isbn=" + isbn + ", publicDate=" + publicDate + ", price=" + price + ", description=" + description
//				+ "]";
//	}
//	
}
