package com.cg.bookstore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bookstore.dao.BookDao;
import com.cg.bookstore.entities.BookEntities;


@Service
@Transactional
public class BookServiceimpl implements BookService{
	@Autowired BookDao ibookDao;

	@Override
	public BookEntities create(BookEntities book) {
		// TODO Auto-generated method stub
		return ibookDao.save(book);
	}
	
//	public void newCustomer(BookEntities book) {
//System.out.println(book);
//		ibookDao.save(book);
//	
//	}
//
//	@Override
//	public BookEntities newBook(BookEntities book) {
//		// TODO Auto-generated method stub
//		System.out.println(book);
//		return ibookDao.save(book);
//	}
	

}
