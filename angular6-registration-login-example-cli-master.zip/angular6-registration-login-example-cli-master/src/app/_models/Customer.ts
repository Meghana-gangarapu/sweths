export class Customer {
    customerId: number;
    customerName: string;
    password: string;
    email: string;
    address: string;
	    city: string;
    zipCode: number;
country: string
    mobileNumber: string;

}