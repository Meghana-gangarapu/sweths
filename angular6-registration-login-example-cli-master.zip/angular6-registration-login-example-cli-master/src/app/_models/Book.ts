export class Book {
    bookId: number;
    category: string;
   title: string;
    author: string;
    isbn: string;
	    
    price: number;
description: string;
   

}