package com.cg.registration.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.registration.bean.RegistrationForm;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;
RegistrationForm registrationForm; 
//By about;
	
	String Title;
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	
	registrationForm=new RegistrationForm();
PageFactory	.initElements(driver, registrationForm);
	
	}
	@After
	public void finish() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}
@Given("^Registration form details$")
public void registration_form_details() throws Throwable {
    driver.get("file:///C:/BDD/RegistrationForm-048/Webpage/RegistrationForm.html");
  
}

@When("^check title for registration form$")
public void check_title_for_registration_form() throws Throwable {
	Title=driver.getTitle();
}

@Then("^title should come RegistrationForm$")
public void title_should_come_RegistrationForm() throws Throwable {
	String expected="Registration Form";
	  String actual=Title;
	  assertEquals(expected, actual);
}

@When("^clicking on next without entering the 'user id'$")
public void clicking_on_next_without_entering_the_user_id() throws Throwable {
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
public void getting_alert_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="User Id should not be empty / length be between 5 to 12";
	   assertEquals(expected, actual);  
}

@When("^clicking on next without entering the 'user password'$")
public void clicking_on_next_without_entering_the_user_password() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setUserName("swetha");
	registrationForm.register();
	   Thread.sleep(1000);

}

@Then("^getting alert 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
public void getting_alert_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="Password should not be empty / length be between 7 to 12";
	   assertEquals(expected, actual);  
}

@When("^clicking on next without entering the 'Name'$")
public void clicking_on_next_without_entering_the_Name() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setUserPassword("pabboju");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'Name should not be empty and must have alphabet characters only'$")
public void getting_alert_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="Name should not be empty and must have alphabet characters only";
	   assertEquals(expected, actual);  
}

@When("^clicking on next without entering the 'Address'$")
public void clicking_on_next_without_entering_the_Address() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setName("sweety");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'User address must have alphanumeric characters only'$")
public void getting_alert_User_address_must_have_alphanumeric_characters_only() throws Throwable {
	
	String actual=driver.switchTo().alert().getText();
	   String expected="User address must have alphanumeric characters only";
	   assertEquals(expected, actual); 
}

@When("^clicking on next without entering the 'country'$")
public void clicking_on_next_without_entering_the_country() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setAddress("fatehnagar");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'Select your country from the list'$")
public void getting_alert_Select_your_country_from_the_list() throws Throwable {

	String actual=driver.switchTo().alert().getText();
	   String expected="Select your country from the list";
	   assertEquals(expected, actual); 
}

@When("^clicking on next without entering the 'zip'$")
public void clicking_on_next_without_entering_the_zip() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setCountry("austrila");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'ZIP code must have numeric characters only'$")
public void getting_alert_ZIP_code_must_have_numeric_characters_only() throws Throwable {

	String actual=driver.switchTo().alert().getText();
	   String expected="ZIP code must have numeric characters only";
	   assertEquals(expected, actual);
}

@When("^clicking on next without entering  vaild email$")
public void clicking_on_next_without_entering_vaild_email() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setZipCode("4004");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'You have entered an invalid email address!'$")
public void getting_alert_You_have_entered_an_invalid_email_address() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="You have entered an invalid email address!";
	   assertEquals(expected, actual);
}

@When("^clicking on next with entering vaildss emailaddress$")
public void clicking_on_next_with_entering_vaildss_emailaddress() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setEmail("swetha@gmail");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^You have entered an invalid email address enter again'$")
public void you_have_entered_an_invalid_email_address_enter_again() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="You have entered an invalid email address!";
	   assertEquals(expected, actual);
}

@When("^clicking on next without entering gender$")
public void clicking_on_next_without_entering_gender() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setEmail("swetha@gmail.com");
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^getting alert 'Please Select gender'$")
public void getting_alert_Please_Select_gender() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="Please Select gender";
	   assertEquals(expected, actual);
}

@When("^clicking on next if all fields are valid$")
public void clicking_on_next_if_all_fields_are_valid() throws Throwable {
	driver.switchTo().alert().dismiss();
	registrationForm.setGender(1);
	registrationForm.register();
	   Thread.sleep(1000);
}

@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile''$")
public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {
	String actual=driver.switchTo().alert().getText();
	   String expected="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
	   assertEquals(expected, actual);
	   driver.switchTo().alert().dismiss();
	System.out.println("success");
}

}
