package com.cg.registration.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationForm {
	@FindBy(how=How.NAME,name="userid")
WebElement userName;
	@FindBy(how=How.NAME,name="passid")
WebElement userPassword;
	@FindBy(how=How.NAME,name="username")
WebElement name;
	@FindBy(how=How.NAME,name="address")
WebElement address;
	@FindBy(how=How.NAME,name="country")
WebElement country;
	@FindBy(how=How.NAME,name="zip")
WebElement zipCode;
	@FindBy(how=How.XPATH,xpath="/html/body/form/ul/li[14]/input")
WebElement email;
	@FindBy(how=How.NAME,name="sex")
List<WebElement> gender;
	
	@FindBy(how=How.NAME,name="submit")
WebElement register;
public void register() {
	register.click();
}
/*public void setTech(int gender) {
	this.gender.get(gender).click();
}
*/
public void setUserName(String userName) {
	this.userName.sendKeys(userName);
}
public void setUserPassword(String userPassword) {
	this.userPassword.sendKeys(userPassword);
}
public void setName(String name) {
	this.name.sendKeys(name);
}
public void setAddress(String address) {
	this.address.sendKeys(address);
}
public void setCountry(String country) {
	this.country.sendKeys(country);
}
public void setZipCode(String zipCode) {
	this.zipCode.sendKeys(zipCode);
}
public void setEmail(String email) {
	this.email.clear();
	this.email.sendKeys(email);
}
public void setGender(int gender) {
	this.gender.get(gender).click();
}


}
