package com.cg.employee.step;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.employee.bean.EmployeePage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeStepDef {
	WebDriver driver;
	EmployeePage employeePage;
	String Title;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	employeePage=new EmployeePage();
	PageFactory.initElements(driver, employeePage);
	}
	@After
	public void finish() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}
	
	@Given("^empolyee page validation$")
	public void empolyee_page_validation() throws Throwable {
	    driver.get("file:///C:/Users/SP26/Desktop/WebPages/Employee%20Details.html");
	}

	@When("^check title for employee page$")
	public void check_title_for_employee_page() throws Throwable {
	   Title=driver.getTitle();
	}

	@Then("^title should come Employee Details$")
	public void title_should_come_Employee_Details() throws Throwable {
		 String expected="Employee Details";
		  String actual=Title;
		  assertEquals(expected, actual);
	}

	@When("^clicking on next without entering First name$")
	public void clicking_on_next_without_entering_First_name() throws Throwable {
		employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the First Name'$")
	public void getting_alert_please_fill_the_First_Name() throws Throwable {
		 String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the First Name";
		   assertEquals(expected, actual);   
	}

	@When("^clicking on next without entering Last name$")
	public void clicking_on_next_without_entering_Last_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		 employeePage.setFirstName("swetha");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the Last Name'$")
	public void getting_alert_please_fill_the_Last_Name() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the Last Name";
		   assertEquals(expected, actual);   
	}

	@When("^clicking on next without entering email$")
	public void clicking_on_next_without_entering_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		 employeePage.setLastName("pabboju");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the email'$")
	public void getting_alert_please_fill_the_email() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the Email";
		   assertEquals(expected, actual);   
	}

	@When("^clicking on next without entering vaild email$")
	public void clicking_on_next_without_entering_vaild_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		 employeePage.setEmail("aaa");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the valid email\\.'$")
	public void getting_alert_please_fill_the_valid_email() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please enter valid Email Id.";
		   assertEquals(expected, actual);
	}

	@When("^clicking on next without entering  contact$")
	public void clicking_on_next_without_entering_contact() throws Throwable {
		driver.switchTo().alert().dismiss();
		 employeePage.setEmail("swetha@gmail.com");;
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the Contact No\\.'$")
	public void getting_alert_please_fill_the_Contact_No() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the Contact No.";
		   assertEquals(expected, actual);
	}

	@When("^clicking on next without entering  vaild contact$")
	public void clicking_on_next_without_entering_vaild_contact() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setContact("2315578695");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please fill the  valid Contact No\\.'$")
	public void getting_alert_please_fill_the_valid_Contact_No() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please enter valid Contact no.";
		   assertEquals(expected, actual);
	}

	@When("^clicking on next without entering lineone$")
	public void clicking_on_next_without_entering_line_one() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setContact("9550501379");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}
	@Then("^getting alert 'please fill the Address lineone'$")
	public void getting_alert_please_fill_the_Address_line_one() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the address line 1";
		   assertEquals(expected, actual);
	}
	@When("^clicking on next without entering linetwo$")
	public void clicking_on_next_without_entering_line_two() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setAddLineOne("hrstuftf");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}
	@Then("^getting alert 'please fill the Address linetwo'$")
	public void getting_alert_please_fill_the_Address_linetwo() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please fill the address line 2";
		   assertEquals(expected, actual);
	}
	

	@When("^clicking on next without entering city$")
	public void clicking_on_next_without_entering_city() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setAddLineTwo("hrstuftf");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please select city'$")
	public void getting_alert_please_select_city() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please select city";
		   assertEquals(expected, actual);
	}

	@When("^clicking on next without entering state$")
	public void clicking_on_next_without_entering_state() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setCity("hyderabad");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^getting alert 'please select state'$")
	public void getting_alert_please_select_state() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Please select state";
		   assertEquals(expected, actual);
	}
	

	@When("^clicking on next if all feilds are valid$")
	public void clicking_on_next_if_all_feilds_are_valid() throws Throwable {
		driver.switchTo().alert().dismiss();
		employeePage.setState("telanagana");
		 employeePage.clickLink();
		   Thread.sleep(1000);
	}

	@Then("^alert 'Personal details are validated and accepted successfully\\.'$")
	public void alert_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		String actual=driver.switchTo().alert().getText();
		   String expected="Personal details are validated and accepted successfully.";
		   assertEquals(expected, actual);
		   driver.switchTo().alert().dismiss();
		   employeePage.clickLink();
	}

	@Given("^Course page validation$")
	public void course_page_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^check title for course page$")
	public void check_title_for_course_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^title should come  Courses to opt$")
	public void title_should_come_Courses_to_opt() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicking button without entering Graduation$")
	public void clicking_button_without_entering_Graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^getting alert 'Please Select Graduation'$")
	public void getting_alert_Please_Select_Graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicking button without entering percentage$")
	public void clicking_button_without_entering_percentage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^getting alert 'Please fill percentage detail'$")
	public void getting_alert_Please_fill_percentage_detail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^getting alert 'Please fill Passing Year'$")
	public void getting_alert_Please_fill_Passing_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicking register without project name$")
	public void clicking_register_without_project_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^getting alert 'Please fill Project Name'$")
	public void getting_alert_Please_fill_Project_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicking register without technologies used$")
	public void clicking_register_without_technologies_used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^getting alert 'Please Select Technologies Used'$")
	public void getting_alert_Please_Select_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicking on next if all fields are valid$")
	public void clicking_on_next_if_all_fields_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
